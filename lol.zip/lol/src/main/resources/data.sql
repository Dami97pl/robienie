INSERT INTO liga (id, nazwa) VALUES (1, 'PGE Ekstraliga');
INSERT INTO druzyna (id, nazwa, liga_id) VALUES (1, 'Sparta Wrocław', 1);
INSERT INTO zawodnik (id, imie, nazwisko, druzyna_id) VALUES (1, 'Maciej', 'Janowski', 1);