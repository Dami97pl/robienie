CREATE TABLE liga (
    id BIGINT PRIMARY KEY,
    nazwa VARCHAR(100) NOT NULL
);

CREATE TABLE druzyna (
    id BIGINT PRIMARY KEY,
    nazwa VARCHAR(100) NOT NULL,
    liga_id BIGINT,
    FOREIGN KEY (liga_id) REFERENCES liga(id)
);

CREATE TABLE zawodnik (
    id BIGINT PRIMARY KEY,
    imie VARCHAR(100),
    nazwisko VARCHAR(100),
    druzyna_id BIGINT,
    FOREIGN KEY (druzyna_id) REFERENCES druzyna(id)
);

CREATE TABLE mecz (
    id BIGINT PRIMARY KEY,
    data DATE,
    gospodarze_id BIGINT,
    goscie_id BIGINT,
    FOREIGN KEY (gospodarze_id) REFERENCES druzyna(id),
    FOREIGN KEY (goscie_id) REFERENCES druzyna(id)
);

CREATE TABLE wynik (
    id BIGINT PRIMARY KEY,
    punkty_gospodarzy INT CHECK (punkty_gospodarzy >= 0),
    punkty_gosci INT CHECK (punkty_gosci >= 0),
    mecz_id BIGINT,
    FOREIGN KEY (mecz_id) REFERENCES mecz(id)
);