package com.example.lol.repository;

import com.example.lol.model.Wynik;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface WynikRepository extends JpaRepository<Wynik, Long> {

}
