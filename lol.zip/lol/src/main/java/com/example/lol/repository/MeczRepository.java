package com.example.lol.repository;

import com.example.lol.model.Mecz;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface MeczRepository extends JpaRepository<Mecz, Long> {
    List<Mecz> findByLigaId(Long ligaId);
}
