package com.example.lol.model;

import jakarta.persistence.*;
import lombok.*;
import jakarta.persistence.Id;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Builder
public class Mecz {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private Liga liga;

    @ManyToOne
    @JoinColumn(name = "home_id")
    private Druzyna home;

    @ManyToOne
    @JoinColumn(name = "away_id")
    private Druzyna away;

    @OneToOne(mappedBy = "mecz", cascade = CascadeType.ALL)
    private Wynik wynik;

    private java.time.LocalDate data;
}
