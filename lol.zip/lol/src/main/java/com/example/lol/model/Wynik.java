package com.example.lol.model;

import jakarta.persistence.*;
import lombok.*;
import jakarta.persistence.Id;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Wynik {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private int punktyHome;

    private int punktyAway;

    @OneToOne
    @JoinColumn(name = "mecz_id")
    private Mecz mecz;
}