package com.example.lol.controller;

import com.example.lol.model.Druzyna;
import com.example.lol.model.Zawodnik;
import com.example.lol.repository.DruzynaRepository;
import com.example.lol.repository.ZawodnikRepository;
import jakarta.transaction.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
@RequestMapping("/api/zawodnicy")

public class ZawodnikController {

    private final ZawodnikRepository zawodnikRepository;
    private final DruzynaRepository druzynaRepository;

    public ZawodnikController(ZawodnikRepository zawodnikRepository, DruzynaRepository druzynaRepository) {
        this.zawodnikRepository = zawodnikRepository;
        this.druzynaRepository = druzynaRepository;
    }

    @GetMapping
    public List<Zawodnik> all(){
        return zawodnikRepository.findAll();
    }

    @PostMapping
    public Zawodnik add(@RequestBody Zawodnik zawodnik){
        return zawodnikRepository.save(zawodnik);
    }

    @DeleteMapping("/{id}")
    public void delete(@PathVariable Long id) {
        zawodnikRepository.deleteById(id);
    }

    @Transactional
    @PutMapping("/{id}/druzyna/{druzynaId}")
    public Zawodnik przypisz(@PathVariable Long id, @PathVariable Long druzynaId){

        Zawodnik zawodnik = zawodnikRepository.findById(id).orElseThrow();
        Druzyna druzyna = druzynaRepository.findById(druzynaId).orElseThrow();

        zawodnik.setDruzyna(druzyna);

        return zawodnik;
    }

    @GetMapping("/druzyna/{id}")
    public List<Zawodnik> zawodnicyDruzyny(@PathVariable Long id){
        return zawodnikRepository.findByDruzynaId(id);
    }
}
