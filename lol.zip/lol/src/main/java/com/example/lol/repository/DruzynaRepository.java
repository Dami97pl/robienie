package com.example.lol.repository;

import com.example.lol.model.Druzyna;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DruzynaRepository extends JpaRepository<Druzyna, Long> {

}