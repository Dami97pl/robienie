package com.example.lol.repository;

import com.example.lol.model.Zawodnik;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface ZawodnikRepository extends JpaRepository<Zawodnik, Long> {
    List<Zawodnik> findByDruzynaId(Long druzynaId);
}
