package com.example.lol.controller;

import com.example.lol.model.Mecz;
import com.example.lol.model.Wynik;
import com.example.lol.repository.MeczRepository;
import com.example.lol.repository.WynikRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/mecze")
@RequiredArgsConstructor
public class MeczController {
    private final MeczRepository meczRepo;
    private final WynikRepository wynikRepo;

    @PostMapping
    public Mecz dodajMecz(@RequestBody Mecz mecz) {
        return meczRepo.save(mecz);
    }

    @PostMapping("/{id}/wynik")
    public Wynik dodajWynik(@PathVariable Long id, @RequestBody Wynik wynik) {
        Mecz m = meczRepo.findById(id).orElseThrow();
        wynik.setMecz(m);
        return wynikRepo.save(wynik);
    }
}