package com.example.lol.controller.dto;


import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Getter
@AllArgsConstructor
@NoArgsConstructor
public class TabelaWiersz {
    private String druzyna;
    private int mecze;
    private int punkty;
}
