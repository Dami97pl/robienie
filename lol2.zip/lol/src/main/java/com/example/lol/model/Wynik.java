package com.example.lol.model;

import jakarta.persistence.*;
import lombok.*;
import jakarta.persistence.Id;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Wynik {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private int punktyHome;
    private int punktyAway;

    public void setPunktyHome(int punktyHome) {
        if (punktyHome < 0) {
            throw new IllegalArgumentException("Punkty nie mogą być ujemne!");
        }
        this.punktyHome = punktyHome;
    }

    public void setPunktyAway(int punktyAway) {
        if (punktyAway < 0) {
            throw new IllegalArgumentException("Punkty nie mogą być ujemne!");
        }
        this.punktyAway = punktyAway;
    }

    @OneToOne
    @JoinColumn(name = "mecz_id")
    private Mecz mecz;
}