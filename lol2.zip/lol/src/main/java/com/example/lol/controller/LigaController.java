package com.example.lol.controller;

import com.example.lol.controller.dto.TabelaWiersz;
import com.example.lol.model.*;
import com.example.lol.repository.LigaRepository;
import com.example.lol.repository.MeczRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/api/ligi")
@RequiredArgsConstructor
public class LigaController {
    private final LigaRepository ligaRepo;
    private final MeczRepository meczRepo;

    @GetMapping("/{id}/tabela")
    public List<TabelaWiersz> getTabela(@PathVariable Long id) {
        Liga liga = ligaRepo.findById(id).orElseThrow();
        List<TabelaWiersz> tabela = new ArrayList<>();

        for (Druzyna d : liga.getDruzyny()) {
            final int[] pkt = {0};
            int meczeCount = (int) meczRepo.findAll().stream()
                    .filter(m -> m.getWynik() != null && (m.getHome().equals(d) || m.getAway().equals(d)))
                    .count();

            meczRepo.findAll().stream()
                    .filter(m -> m.getWynik() != null)
                    .forEach(m -> {
                        int pH = m.getWynik().getPunktyHome();
                        int pA = m.getWynik().getPunktyAway();
                        if (m.getHome().equals(d)) {
                            if (pH > pA) pkt[0] += 2; else if (pH == pA) pkt[0] += 1;
                        } else if (m.getAway().equals(d)) {
                            if (pA > pH) pkt[0] += 2; else if (pH == pA) pkt[0] += 1;
                        }
                    });
            tabela.add(new TabelaWiersz(d.getName(), meczeCount, pkt[0]));
        }
        tabela.sort((a, b) -> Integer.compare(b.getPunkty(), a.getPunkty()));
        return tabela;
    }
}